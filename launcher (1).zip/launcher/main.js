const { app, BrowserWindow, ipcMain, shell, dialog, safeStorage } = require('electron');
const { Auth } = require('msmc');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { pipeline } = require('stream/promises');
const { Readable, Transform } = require('stream');
const { Client, Authenticator } = require('minecraft-launcher-core');
const AdmZip = require('adm-zip');

// ---- Config (build.gradle / gradle.properties se liya gaya) ----
const MC_VERSION = '1.21.11';
const FABRIC_LOADER = '0.18.4';
const FABRIC_API_VERSION = '0.141.3+1.21.11';
const FABRIC_ID = `fabric-loader-${FABRIC_LOADER}-${MC_VERSION}`;
const GITHUB_REPO = 'iamniketan44-cpu/ghost-client';
const JAVA_URL =
  'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse';
const UA = 'GhostLauncher/1.0';

let win = null;
let busy = false;

const ROOT = () => path.join(app.getPath('appData'), '.ghostlauncher');
const SETTINGS_FILE = () => path.join(ROOT(), 'settings.json');

// ---- Helpers ----
const send = (ch, data) => {
  if (win && !win.isDestroyed()) win.webContents.send(ch, data);
};
const log = (m) => send('log', String(m).slice(0, 400));
const progress = (pct, text) =>
  send('progress', { pct: Math.max(0, Math.min(100, Math.round(pct))), text });

function loadSettings() {
  try {
    return JSON.parse(fs.readFileSync(SETTINGS_FILE(), 'utf8'));
  } catch {
    return {};
  }
}
function saveSettings(s) {
  fs.mkdirSync(ROOT(), { recursive: true });
  fs.writeFileSync(SETTINGS_FILE(), JSON.stringify({ ...loadSettings(), ...s }));
}

// ---- Premium (Microsoft) login ----
function encryptToken(t) {
  try {
    if (safeStorage.isEncryptionAvailable()) {
      return safeStorage.encryptString(t).toString('base64');
    }
  } catch {}
  return null; // encrypt na ho paye to save nahi karte, har baar login hoga
}
function decryptToken(b64) {
  try {
    return safeStorage.decryptString(Buffer.from(b64, 'base64'));
  } catch {
    return null;
  }
}

let premiumAuth = null;

async function getPremiumAuth() {
  const authManager = new Auth('select_account');
  const s = loadSettings();
  let xbox = null;

  if (s.msToken) {
    const saved = decryptToken(s.msToken);
    if (saved) {
      try {
        progress(1, 'Microsoft account check ho raha hai...');
        xbox = await authManager.refresh(saved);
      } catch {
        xbox = null;
      }
    }
  }
  if (!xbox) {
    progress(1, 'Microsoft login window khul rahi hai...');
    try {
      xbox = await authManager.launch('electron');
    } catch (e) {
      const m = String((e && (e.message || e)) || '');
      if (/closed/i.test(m)) throw new Error('Login window band kar di gayi. Dobara Play dabayein.');
      throw new Error('Microsoft login fail hua: ' + m);
    }
  }

  const token = await xbox.getMinecraft();
  if (typeof token.isDemo === 'function' && token.isDemo()) {
    throw new Error('Is Microsoft account par Minecraft Java Edition nahi hai.');
  }
  const name = token.profile && token.profile.name;
  let enc = null;
  try {
    enc = encryptToken(xbox.save());
  } catch {}
  saveSettings({ msToken: enc, msName: name || null });
  send('account', name || '');
  premiumAuth = token.mclc();
  return premiumAuth;
}

// ---- Capes (Mojang API, sirf premium) ----
async function mcs(method, p, body) {
  const doReq = () =>
    fetch('https://api.minecraftservices.com' + p, {
      method,
      headers: {
        Authorization: `Bearer ${premiumAuth.access_token}`,
        'Content-Type': 'application/json',
        'User-Agent': UA,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  if (!premiumAuth) await getPremiumAuth();
  let res = await doReq();
  if (res.status === 401) {
    await getPremiumAuth();
    res = await doReq();
  }
  if (!res.ok) throw new Error(`Mojang server error (${res.status})`);
  return res.json();
}

function mapCapes(profile) {
  return (profile.capes || [])
    .filter((c) => /^https:\/\/textures\.minecraft\.net\//.test(c.url || ''))
    .map((c) => ({
      id: c.id,
      alias: c.alias || 'Cape',
      url: c.url,
      active: c.state === 'ACTIVE',
    }));
}

ipcMain.handle('cape-list', async () => {
  if (busy) return { capes: [], error: 'Game chal raha hai. Pehle game band karein.' };
  try {
    return { capes: mapCapes(await mcs('GET', '/minecraft/profile')) };
  } catch (e) {
    return { capes: [], error: e.message || String(e) };
  } finally {
    progress(0, '');
  }
});

ipcMain.handle('cape-set', async (_e, id) => {
  if (busy) return { capes: [], error: 'Game chal raha hai. Pehle game band karein.' };
  try {
    let profile;
    if (id === null) {
      profile = await mcs('DELETE', '/minecraft/profile/capes/active');
    } else if (typeof id === 'string' && /^[0-9a-f-]{36}$/i.test(id)) {
      profile = await mcs('PUT', '/minecraft/profile/capes/active', { capeId: id });
    } else {
      return { capes: [], error: 'Galat cape.' };
    }
    return { capes: mapCapes(profile) };
  } catch (e) {
    return { capes: [], error: e.message || String(e) };
  } finally {
    progress(0, '');
  }
});

async function fetchJson(url, extraHeaders = {}) {
  const res = await fetch(url, { headers: { 'User-Agent': UA, ...extraHeaders } });
  if (!res.ok) throw new Error(`Request fail (${res.status}): ${url}`);
  return res.json();
}

async function download(url, dest, onPct) {
  const res = await fetch(url, { headers: { 'User-Agent': UA }, redirect: 'follow' });
  if (!res.ok || !res.body) throw new Error(`Download fail (${res.status}): ${url}`);
  const total = Number(res.headers.get('content-length')) || 0;
  let done = 0;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const part = dest + '.part';
  const counter = new Transform({
    transform(chunk, _enc, cb) {
      done += chunk.length;
      if (total && onPct) onPct(done / total);
      cb(null, chunk);
    },
  });
  await pipeline(Readable.fromWeb(res.body), counter, fs.createWriteStream(part));
  fs.renameSync(part, dest);
}

function removeOthers(dir, regex, keepName) {
  for (const f of fs.readdirSync(dir)) {
    if (regex.test(f) && f !== keepName) {
      try {
        fs.unlinkSync(path.join(dir, f));
      } catch {}
    }
  }
}
const hasJar = (dir, regex) => fs.readdirSync(dir).some((f) => regex.test(f));

// ---- Java 21 (automatic) ----
async function ensureJava() {
  const javaw = path.join(ROOT(), 'runtime', 'jre21', 'bin', 'javaw.exe');
  if (fs.existsSync(javaw)) return javaw;

  log('Java 21 download ho raha hai (sirf pehli baar)...');
  const runtime = path.join(ROOT(), 'runtime');
  const zipPath = path.join(runtime, 'jre21.zip');
  await download(JAVA_URL, zipPath, (p) =>
    progress(2 + p * 20, `Java download ho raha hai ${Math.round(p * 100)}%`)
  );

  progress(23, 'Java extract ho raha hai...');
  const tmp = path.join(runtime, 'tmp');
  fs.rmSync(tmp, { recursive: true, force: true });
  new AdmZip(zipPath).extractAllTo(tmp, true);
  const inner = fs.readdirSync(tmp).find((n) => fs.statSync(path.join(tmp, n)).isDirectory());
  if (!inner) throw new Error('Java zip sahi nahi tha');
  fs.rmSync(path.join(runtime, 'jre21'), { recursive: true, force: true });
  fs.renameSync(path.join(tmp, inner), path.join(runtime, 'jre21'));
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.rmSync(zipPath, { force: true });

  if (!fs.existsSync(javaw)) throw new Error('Java install nahi ho paya');
  return javaw;
}

// ---- Fabric profile ----
async function ensureFabric() {
  const dir = path.join(ROOT(), 'versions', FABRIC_ID);
  const file = path.join(dir, `${FABRIC_ID}.json`);
  if (fs.existsSync(file)) return;
  log('Fabric setup ho raha hai...');
  const profile = await fetchJson(
    `https://meta.fabricmc.net/v2/versions/loader/${MC_VERSION}/${FABRIC_LOADER}/profile/json`
  );
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(profile));
}

// ---- Mods: Fabric API + Ghost Menu ----
async function ensureMods() {
  const mods = path.join(ROOT(), 'game', 'mods');
  fs.mkdirSync(mods, { recursive: true });

  // Fabric API (Modrinth)
  try {
    const q =
      `https://api.modrinth.com/v2/project/fabric-api/version` +
      `?game_versions=${encodeURIComponent(JSON.stringify([MC_VERSION]))}` +
      `&loaders=${encodeURIComponent(JSON.stringify(['fabric']))}`;
    const versions = await fetchJson(q);
    const v = versions.find((x) => x.version_number === FABRIC_API_VERSION) || versions[0];
    if (!v) throw new Error('Fabric API version nahi mila');
    const f = v.files.find((x) => x.primary) || v.files[0];
    const dest = path.join(mods, f.filename);
    if (!fs.existsSync(dest)) {
      log('Fabric API download ho raha hai...');
      await download(f.url, dest);
    }
    removeOthers(mods, /^fabric-api.*\.jar$/i, f.filename);
  } catch (e) {
    if (!hasJar(mods, /^fabric-api.*\.jar$/i)) throw e;
    log('Fabric API update skip: ' + e.message);
  }

  // Ghost Menu (GitHub release)
  try {
    const releases = await fetchJson(
      `https://api.github.com/repos/${GITHUB_REPO}/releases?per_page=20`,
      { Accept: 'application/vnd.github+json' }
    );
    let asset = null;
    for (const r of releases) {
      if (r.draft) continue;
      asset = r.assets.find((a) => /^ghostmenu.*\.jar$/i.test(a.name));
      if (asset) break;
    }
    if (!asset) throw new Error('GitHub release mein ghostmenu jar nahi mili');
    const dest = path.join(mods, asset.name);
    const same = fs.existsSync(dest) && fs.statSync(dest).size === asset.size;
    if (!same) {
      log('Ghost Menu download ho raha hai...');
      await download(asset.browser_download_url, dest);
    }
    removeOthers(mods, /^ghostmenu.*\.jar$/i, asset.name);
  } catch (e) {
    if (!hasJar(mods, /^ghostmenu.*\.jar$/i)) throw e;
    log('Ghost Menu update skip: ' + e.message);
  }
}

// ---- Play ----
async function play({ mode, username, ram }) {
  if (busy) return;
  busy = true;
  send('state', 'busy');
  try {
    const premium = mode === 'premium';
    if (!premium && !/^[A-Za-z0-9_]{3,16}$/.test(username || '')) {
      throw new Error('Username 3-16 characters ka hona chahiye (sirf English letters, numbers, _).');
    }
    const ramGb = Math.max(1, Number(ram) || 4);
    fs.mkdirSync(ROOT(), { recursive: true });
    saveSettings({ mode: premium ? 'premium' : 'offline', ram: ramGb, ...(premium ? {} : { username }) });

    const auth = premium ? await getPremiumAuth() : Authenticator.getAuth(username);

    progress(1, 'Shuru ho raha hai...');
    const javaPath = await ensureJava();

    progress(30, 'Fabric check ho raha hai...');
    await ensureFabric();

    progress(35, 'Mods check ho rahe hain...');
    await ensureMods();

    progress(40, 'Minecraft files check ho rahi hain...');
    const launcher = new Client();
    launcher.on('debug', (m) => log(m));
    launcher.on('data', (m) => log(m));
    launcher.on('progress', (e) => {
      if (e && e.total) {
        progress(40 + 55 * (e.task / e.total), `Minecraft files: ${e.type} ${e.task}/${e.total}`);
      }
    });
    launcher.on('close', (code) => {
      log(`Game band hua (code ${code})`);
      busy = false;
      progress(0, '');
      send('state', 'idle');
    });

    const proc = await launcher.launch({
      authorization: auth,
      root: ROOT(),
      javaPath,
      version: { number: MC_VERSION, type: 'release', custom: FABRIC_ID },
      memory: { max: `${ramGb}G`, min: '1G' },
      overrides: { gameDirectory: path.join(ROOT(), 'game') },
    });
    if (!proc) throw new Error('Game start nahi hua. "Log dikhao" dabakar error dekhein.');

    progress(100, 'Game chal raha hai! Thodi der mein window khulegi.');
    send('state', 'running');
  } catch (e) {
    busy = false;
    progress(0, '');
    send('state', 'idle');
    send('error', e.message || String(e));
  }
}

// ---- Window ----
function createWindow() {
  win = new BrowserWindow({
    width: 480,
    height: 860,
    resizable: false,
    autoHideMenuBar: true,
    backgroundColor: '#0f1117',
    title: 'Ghost Launcher',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.handle('init', () => {
  const s = loadSettings();
  return {
    username: s.username || '',
    mode: s.mode === 'premium' ? 'premium' : 'offline',
    msName: s.msToken && s.msName ? s.msName : '',
    ram: s.ram || 4,
    totalGb: Math.round(os.totalmem() / 1024 ** 3),
    mcVersion: MC_VERSION,
  };
});
ipcMain.handle('play', (_e, data) => play(data));
ipcMain.handle('ms-logout', () => {
  saveSettings({ msToken: null, msName: null });
  premiumAuth = null;
  return true;
});

// ---- Mods manager ----
const modsDir = () => path.join(ROOT(), 'game', 'mods');
// Fabric API aur Ghost Menu launcher khud manage karta hai
const isManaged = (f) => /^(fabric-api|ghostmenu)/i.test(f);

// Mod ka naam aur icon jar ke andar fabric.mod.json se padhte hain
const metaCache = new Map();
function readModMeta(file) {
  const full = path.join(modsDir(), file);
  let st;
  try {
    st = fs.statSync(full);
  } catch {
    return {};
  }
  const key = `${file}:${st.size}:${st.mtimeMs}`;
  if (metaCache.has(key)) return metaCache.get(key);

  const meta = {};
  try {
    const zip = new AdmZip(full);
    const entry = zip.getEntry('fabric.mod.json');
    if (entry) {
      const json = JSON.parse(entry.getData().toString('utf8').replace(/^﻿/, ''));
      if (typeof json.name === 'string') meta.title = json.name;
      else if (typeof json.id === 'string') meta.title = json.id;

      let iconPath = json.icon;
      if (iconPath && typeof iconPath === 'object') {
        const sizes = Object.keys(iconPath)
          .map(Number)
          .filter(Number.isFinite)
          .sort((a, b) => b - a);
        iconPath = sizes.length ? iconPath[String(sizes[0])] : null;
      }
      if (typeof iconPath === 'string') {
        const iconEntry = zip.getEntry(iconPath.replace(/^\/+/, ''));
        if (iconEntry) {
          const buf = iconEntry.getData();
          if (buf.length <= 400 * 1024) {
            meta.icon = 'data:image/png;base64,' + buf.toString('base64');
          }
        }
      }
    }
  } catch {}
  metaCache.set(key, meta);
  return meta;
}

function listMods() {
  const dir = modsDir();
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => /\.jar$/i.test(f))
    .sort()
    .map((f) => ({ name: f, locked: isManaged(f), ...readModMeta(f) }));
}

ipcMain.handle('list-mods', () => listMods());

ipcMain.handle('add-mods', async () => {
  if (busy) return { mods: listMods(), error: 'Game chal raha hai. Pehle game band karein, phir mod add karein.' };
  const r = await dialog.showOpenDialog(win, {
    title: 'Mod (.jar) chunein',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Fabric mod (.jar)', extensions: ['jar'] }],
  });
  if (!r.canceled) {
    fs.mkdirSync(modsDir(), { recursive: true });
    for (const p of r.filePaths) {
      fs.copyFileSync(p, path.join(modsDir(), path.basename(p)));
    }
  }
  return { mods: listMods() };
});

// ---- Modrinth ----
const FABRIC_API_PROJECT = 'P7dR8mSH'; // launcher isse khud sambhalta hai
const MR = 'https://api.modrinth.com/v2';
const MR_FILE = () => path.join(ROOT(), 'modrinth.json');

function loadMrMap() {
  try {
    return JSON.parse(fs.readFileSync(MR_FILE(), 'utf8'));
  } catch {
    return {};
  }
}
function saveMrMap(m) {
  fs.mkdirSync(ROOT(), { recursive: true });
  fs.writeFileSync(MR_FILE(), JSON.stringify(m));
}

ipcMain.handle('mr-search', async (_e, query) => {
  try {
    const q = String(query || '').trim().slice(0, 80);
    const facets = JSON.stringify([
      ['project_type:mod'],
      ['categories:fabric'],
      [`versions:${MC_VERSION}`],
    ]);
    const url =
      `${MR}/search?query=${encodeURIComponent(q)}` +
      `&facets=${encodeURIComponent(facets)}` +
      `&index=${q ? 'relevance' : 'downloads'}&limit=20`;
    const data = await fetchJson(url);
    const map = loadMrMap();
    const hits = (data.hits || [])
      .filter((h) => h.project_id !== FABRIC_API_PROJECT)
      .map((h) => ({
        id: h.project_id,
        title: h.title,
        description: h.description,
        author: h.author,
        downloads: h.downloads,
        icon: /^https:\/\/cdn\.modrinth\.com\//.test(h.icon_url || '') ? h.icon_url : '',
        installed: !!(map[h.project_id] && fs.existsSync(path.join(modsDir(), map[h.project_id]))),
      }));
    return { hits };
  } catch (e) {
    return { hits: [], error: 'Modrinth se connect nahi ho paya: ' + (e.message || e) };
  }
});

async function installFromModrinth(projectId, seen, depth) {
  if (seen.has(projectId) || depth > 4) return [];
  seen.add(projectId);
  if (projectId === FABRIC_API_PROJECT) return [];

  const url =
    `${MR}/project/${encodeURIComponent(projectId)}/version` +
    `?game_versions=${encodeURIComponent(JSON.stringify([MC_VERSION]))}` +
    `&loaders=${encodeURIComponent(JSON.stringify(['fabric']))}`;
  const versions = await fetchJson(url);
  const v = versions.find((x) => x.version_type === 'release') || versions[0];
  if (!v) throw new Error(`Is mod ka ${MC_VERSION} Fabric version nahi mila.`);

  const f = v.files.find((x) => x.primary) || v.files[0];
  const fname = path.basename(f.filename || '');
  if (!/\.jar$/i.test(fname) || fname !== f.filename) throw new Error('Mod file sahi nahi lagi.');
  if (new URL(f.url).hostname !== 'cdn.modrinth.com') throw new Error('Download link bharosemand nahi.');

  fs.mkdirSync(modsDir(), { recursive: true });
  const dest = path.join(modsDir(), fname);
  if (!fs.existsSync(dest)) {
    log(`Modrinth: ${fname} download ho raha hai...`);
    await download(f.url, dest);
  }
  const map = loadMrMap();
  map[projectId] = fname;
  saveMrMap(map);

  const done = [fname];
  for (const d of v.dependencies || []) {
    if (d.dependency_type === 'required' && d.project_id) {
      done.push(...(await installFromModrinth(d.project_id, seen, depth + 1)));
    }
  }
  return done;
}

ipcMain.handle('mr-install', async (_e, projectId) => {
  if (busy) return { error: 'Game chal raha hai. Pehle game band karein.' };
  if (typeof projectId !== 'string' || !/^[A-Za-z0-9]{6,12}$/.test(projectId)) {
    return { error: 'Galat mod.' };
  }
  try {
    const files = await installFromModrinth(projectId, new Set(), 0);
    return { files, mods: listMods() };
  } catch (e) {
    return { error: e.message || String(e) };
  }
});

ipcMain.handle('remove-mod', (_e, name) => {
  if (busy) return { mods: listMods(), error: 'Game chal raha hai. Pehle game band karein.' };
  if (
    typeof name === 'string' &&
    path.basename(name) === name &&
    /\.jar$/i.test(name) &&
    !isManaged(name)
  ) {
    try {
      fs.unlinkSync(path.join(modsDir(), name));
    } catch {}
  }
  return { mods: listMods() };
});
ipcMain.handle('open-folder', () => {
  fs.mkdirSync(path.join(ROOT(), 'game'), { recursive: true });
  return shell.openPath(path.join(ROOT(), 'game'));
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
